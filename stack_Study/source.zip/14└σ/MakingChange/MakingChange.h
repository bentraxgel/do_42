void GetChange( int Price, int Pay, int CoinUnits[], int Change[], int Size );
int  CountCoins( int Amount, int CoinUnit);
void PrintChange( int CoinUnits[], int Change[], int Size );
